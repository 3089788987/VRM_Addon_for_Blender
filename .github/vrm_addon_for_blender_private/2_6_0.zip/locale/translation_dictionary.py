from . import ja_jp, zh_cn

translation_dictionary = {
    ja_jp.locale_key: ja_jp.translation_dictionary,
    zh_cn.locale_key: zh_cn.translation_dictionary,
}
